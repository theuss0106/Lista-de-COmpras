/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.listadecompras;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class ListaDeCompras {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
